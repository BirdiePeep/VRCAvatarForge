﻿using System;
using VRC.SDK3.Avatars.Components;

namespace Tropical.AvatarForge
{
    [Serializable]
    public abstract class BehaviourGroup: Feature
    {
        //public abstract void GetActions(List<BehaviourItem> output);
        //public abstract BehaviourItem AddAction();
        //public abstract void RemoveAction(BehaviourItem action);
        //public abstract void InsertAction(int index, BehaviourItem action);
        //public virtual bool CanUseLayer(BehaviourGroup.AnimationLayer layer) { return true; }
    }
}