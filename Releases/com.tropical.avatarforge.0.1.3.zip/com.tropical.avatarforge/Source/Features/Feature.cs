﻿
namespace Tropical.AvatarForge
{
    [System.Serializable]
    public abstract class Feature
    {
    }
}

