﻿using UnityEngine;

namespace Tropical.AvatarForge
{
    [ExecuteAlways]
    public class AnimationRecorderProxy : MonoBehaviour
    {
    }
}

