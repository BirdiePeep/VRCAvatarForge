using UnityEngine;

namespace Tropical.AvatarForge
{
    public class IgnorePhysbones : Feature
    {
        public Transform[] transforms;
    }
}

